﻿using UnityEngine;
public class Loader
{
    GameObject gameObject;

    void Load()
    {
        gameObject = GameObject.CreatePrimitive(PrimitiveType.Cube);
        gameObject.AddComponent<Script>();
    }
}

public class Script : MonoBehaviour
{

}
